function OL(str) {
    return /^[A-Za-z\s]*$/.test(str);
}
async function sign_up() {
    document.getElementById("title").style.margin =
    "0px 0px 0px 0px";
    document.getElementById("fail").innerHTML = "The Site is under updating";
    document.getElementById("fail").style.display = "block";
    // if (!navigator.onLine) {
    //     window.alert("Check Internet Connection!");
    //     return false;
    // }
    // var x = true;
    // var username = document.getElementById("username").value;
    // var code = document.getElementById("code").value;
    // var xrr = this.OL(username);

    // document.getElementById("code_error").innerHTML = "";
    // document.getElementById("code").style = "margin-bottom: 15px";
    // document.getElementById("username_error").innerHTML = "";
    // document.getElementById("fail").style.display = "none";
    // document.getElementById("title").style.margin = "0px 0px 10px 0px";

    // if (xrr === false) {
    //     document.getElementById("username_error").innerHTML =
    //         "Only letters and spaces allowed";
    //     document.getElementById("username").style.marginBottom = "0px";
    //     x = false;
    // }
    // if (username.length > 20) {
    //     document.getElementById("username_error").innerHTML =
    //         "Username length must be under 20";
    //     document.getElementById("username").style.marginBottom = "0px";
    //     x = false;
    // }

    // if (code.length === 0) {
    //     document.getElementById("code_error").innerHTML = "Code is required!";
    //     document.getElementById("code").style = "margin-bottom: 0px";
    //     document.getElementById("code_error").style = "height: 1px;";
    //     document.getElementById("code_error").style = "font-size: 1px;";
    //     document.getElementById("code_error").style = "color: rgb(255, 0, 0)";
    //     x = false;
    // }
    // if (username.length === 0) {
    //     document.getElementById("username_error").innerHTML =
    //         "Username is required!";
    //     document.getElementById("username").style.marginBottom = "0px";
    //     x = false;
    // }

    // if (x === true) {
    //     document.getElementById("overlay").style.display = "block";
    //     document.getElementById("popup_loader").style.display = "flex";
    //     if (`${code[0]}${code[1]}${code[2]}` != "123") {
    //         document.getElementById("title").style.margin = "0px 0px 0px 0px";
    //         document.getElementById("fail").innerHTML = "Invalid Data";
    //         document.getElementById("fail").style.display = "block";
    //         document.getElementById("overlay").style.display = "none";
    //         document.getElementById("popup_loader").style.display = "none";
    //         return false;
    //     }
    //     try {
    //         var request = new XMLHttpRequest();
    //         request.open(
    //             "GET",
    //             `https://arugatu.000webhostapp.com/index.php?func=Reg&name=${username}&code=${code}`
    //         );
    //         request.send();
    //         request.onreadystatechange = async function () {
    //             if (this.readyState === 4 && this.status === 200) {
    //                 if (this.responseText === "False") {
    //                     document.getElementById("title").style.margin =
    //                         "0px 0px 0px 0px";
    //                     document.getElementById("fail").innerHTML = "Invalid Code";
    //                     document.getElementById("fail").style.display = "block";
    //                 }
    //                 document.getElementById("overlay").style.display = "none";
    //                 document.getElementById("popup_loader").style.display = "none";
    //                 if (this.responseText === "True") {
    //                     try {
    //                         localStorage.setItem("grade", code[code.length - 1]);
    //                         localStorage.setItem("code", code);
    //                         localStorage.setItem("name", username);
    //                         let request2 = await fetch(
    //                             `https://arugatu.000webhostapp.com/index.php?func=MrsData&code=${code[0]}${code[1]}${code[2]}`
    //                         );
    //                         let teacher = await request2.text();
    //                         localStorage.setItem("teacher", teacher);
    //                         window.location.href = "/main-page"
    //                     } catch (e) {
    //                         window.alert("Check Internet Connection!");
    //                         return false;
    //                     }
    //                 }
    //             }
    //         };
    //     } catch (e) {
    //         console.log("Error");
    //     }
    // }
}
async function Rtli() {
    try {
        var name = await localStorage.getItem("name");
        var code = await localStorage.getItem("code");
        if (code != null) {
            document.getElementById("code").value = code;
        }
        if (name != null) {
            document.getElementById("username").value = name;
        }
    } catch (e) {
        console.log("Error");
    }
}