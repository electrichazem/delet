var r_t = 0;
var data = "";
var student_r = {};
var answers = 0;
var GorR = {};
var Result = false;

async function Start() {
    if (!navigator.onLine) {
        window.alert("Check Internet Connection!");
        window.location.href = "/main-page";
    }
    document.getElementById("overlay").style.display = "block";
    document.getElementById("popup_loader").style.display = "flex";
    var type = localStorage.getItem("type");
    var grade = localStorage.getItem("grade");
    var code = localStorage.getItem("code");
    var name = localStorage.getItem("name");
    var quiz_name = localStorage.getItem("quiz_name");

    let request = await fetch(
        `https://arugatu.000webhostapp.com/index.php?func=MrsOpen&code=${code[0]}${code[1]}${code[2]}&grade=${grade}&quizname=${quiz_name}`
    );
    let MrsOpen = await request.text();

    let request2 = await fetch(
        `https://arugatu.000webhostapp.com/index.php?func=CanEnter&code=${code}&username=${name}&quiz=${quiz_name}`
    );
    let CanEnter = await request2.text();

    quiz_name = `${quiz_name}-${grade}`;
    let TorF = MrsOpen === "True" && CanEnter === "True";
    if (TorF === true && type === "urt") {
        var request3 = await fetch("https://hazememad4.github.io");
        var all_quizes_as_text = await request3.text();
        if (all_quizes_as_text.length === 0) {
            window.location.href = "/main-page";
        }

        document.getElementById("popup_loader").style.display = "none";
        document.getElementById("overlay").style.display = "none";
        data = all_quizes_as_text;
        Part1();
    } else {
        window.location.href = "/main-page";
    }
}

async function Part1() {
    var i;
    var text;
    var x;
    var grade = localStorage.getItem("grade");
    var quiz_name = localStorage.getItem("quiz_name");
    var exam_name;
    if (quiz_name.length === 5) {
        exam_name = `${quiz_name[quiz_name.length - 2]}${quiz_name[quiz_name.length - 1]
            }`;
    }
    if (quiz_name.length === 4) {
        exam_name = `${quiz_name[quiz_name.length - 1]}`;
    }
    quiz_name = `${quiz_name}-${grade}`;
    var data = JSON.parse(this.data);
    data = data[quiz_name];
    document.getElementById("comp1").innerHTML = data["comp1"];
    document.getElementById("comp2").innerHTML = data["comp2"];
    var noq = data["noq"];
    noq++;
    document.getElementById("exam_name").innerHTML = `(${exam_name})`;
    for (i = 1; i < noq; i++) {
        document.getElementById(`question${i}`).innerHTML = data["q"][`q${i}`];
    }
    for (i = 1; i < noq; i++) {
        for (x = 1; x < 4; x++) {
            text = `ans${i}${x}`;
            document.getElementById(`ans${i}${x}`).innerHTML = data["ans"][text];
        }
    }
}

function Ans_Clicked(n) {
    if (Result === false) {
        n = `${n}`;
        if (n.length === 2) {
            document.getElementById(`ans${n[0]}1_b`).style = "display: none";
            document.getElementById(`ans${n[0]}2_b`).style = "display: none";
            document.getElementById(`ans${n[0]}3_b`).style = "display: none";
            document.getElementById(`ans${n}_b`).style = "display: block";
        }
        if (n.length === 3) {
            document.getElementById(`ans${n[0]}${n[1]}1_b`).style =
                "display: none";
            document.getElementById(`ans${n[0]}${n[1]}2_b`).style =
                "display: none";
            document.getElementById(`ans${n[0]}${n[1]}3_b`).style =
                "display: none";
            document.getElementById(`ans${n}_b`).style = "display: block";
        }
    }
}

async function Check() {
    var CorrectedAns = 0;
    answers = 0;
    GorR = {};
    var grade = localStorage.getItem("grade");
    var quiz_name = localStorage.getItem("quiz_name");
    quiz_name = `${quiz_name}-${grade}`;
    var data = JSON.parse(this.data);
    data = data[quiz_name];
    var cans = data["cans"];
    for (var i = 1; i < 26; i++) {
        for (var x = 1; x < 4; x++) {
            if (
                document.getElementById(`ans${i}${x}_b`).style.display === "block"
            ) {
                answers++;
                student_r[i] = x;
            }
        }
    }
    if (answers === 25) {
        for (i = 1; i < 26; i++) {
            if (`${cans[i]}` === `${student_r[i]}`) {
                GorR[`${i}${cans[`${i}`]}`] = "GREEN";
                CorrectedAns++;
            } else {
                GorR[`${i}${student_r[`${i}`]}`] = "RED";
                GorR[`${i}${cans[`${i}`]}`] = "GREEN";
            }
        }
        Result = true;
        var Percentage = parseInt((CorrectedAns / 25) * 100);
        r_t = parseInt(Percentage);
        if (!navigator.onLine) {
            window.alert(
                "You are disconnected! Check Internet Connection then press OK"
            );
        }
        if (!navigator.onLine) {
            window.location.href = "/main-page";
        }
        document.getElementById("overlay").style.display = "block";
        document.getElementById("popup_loader").style.display = "flex";
        var code = localStorage.getItem("code");
        var name = localStorage.getItem("name");
        quiz_name = localStorage.getItem("quiz_name");
        var x = await fetch(
            `https://arugatu.000webhostapp.com/index.php?func=SolveQuiz&code=${code}&name=${name}&quizname=${quiz_name}&dorl=${Percentage}`
        );
        var y = await x.text();
        document.getElementById("overlay").style.display = "none";
        document.getElementById("popup_loader").style.display = "none";
        if (y != "SuccessTrueTrueTrue") {
            window.location.href = "/main-page";
            return false;
        } 
        document.getElementById("r_t").style.display = "block";
        document.getElementById("finish_button").style.display = "none";
        document.getElementById("r_t").innerHTML = `${r_t}%`;
        Part2();
    }
}

function Part2() {
    for (var x = 1; x < 26; x++) {
        for (var z = 1; z < 4; z++)
            document.getElementById(`ans${x}${z}_b`).style.display = "none";
    }
    for (var i = 1; i < 26; i++) {
        for (var x = 1; x < 4; x++) {
            if (GorR[`${i}${x}`] === "GREEN") {
                document.getElementById(`ans${i}${x}_back`).style.backgroundColor = "rgba(21, 255, 0, 0.21)";
            }
            if (GorR[`${i}${x}`] === "RED") {
                document.getElementById(`x${i}${x}_b`).style.display = "block";
            }
        }
    }
}