// function log_out(){
//     window.location.href = "/"
// }
// function Start() {
//     var unit_word = localStorage.getItem("unit_word");
//     document.getElementById("title").innerHTML = `${unit_word}`;
// }
// async function Set_names() {
//     try {
//       if (!navigator.onLine) {
//         window.alert("Check Internet Connection!");
//         router.push({ name: "IndexView" });
//         return false;
//       }
//       var name = await localStorage.getItem("name");
//       var code = await localStorage.getItem("code");
//       var req = await fetch(
//         `https://arugatu.000webhostapp.com/index.php?func=SignIn&code=${code}&name=${name}`
//       );
//       var res = await req.text();
//       if (res === "Success") {
//         document.getElementById("s_name").innerHTML =
//           await localStorage.getItem("name");
//         document.getElementById("t_name").innerHTML =
//           await localStorage.getItem("teacher");
//       } else {
//         window.location.href = "/"
//       }
//     } catch (e) {}
// }
// function card2_clicked(n) {
//     if (n === 1) {
//       localStorage.setItem("unit", "1");
//     }
//     if (n === 2) {
//       localStorage.setItem("unit", "2");
//     }
//     if (n === 3) {
//       localStorage.setItem("unit", "3");
//     }
//     router.push({ name: "unitpage" });
// }
// async function eval_card(n) {
//     document.getElementById("overlay").style.display = "block";
//     document.getElementById("popup_loader").style.display = "flex";
//     if (!navigator.onLine) {
//       window.alert("Check Internet Connection!");
//       router.push({ name: "login" });
//     }
//     var grade = localStorage.getItem("grade");
//     var code = localStorage.getItem("code");
//     var name = localStorage.getItem("name");
//     var quiz_name = `evaluation${n}`;

//     let request = await fetch(
//       `https://arugatu.000webhostapp.com/index.php?func=MrsOpen&code=${code[0]}${code[1]}${code[2]}&grade=${grade}&quizname=${quiz_name}`
//     );
//     let MrsOpen = await request.text();

//     let request2 = await fetch(
//       `https://arugatu.000webhostapp.com/index.php?func=CanEnter&code=${code}&username=${name}&quiz=${quiz_name}`
//     );
//     let CanEnter = await request2.text();
//     document.getElementById("popup_loader").style.display = "none";
//     if (CanEnter === "True" && MrsOpen === "True") {
//       localStorage.setItem("type", "el");
//       localStorage.setItem("quiz_name", quiz_name);
//       if (grade === "3") {
//         document.getElementById("overlay").style.display = "none";
//       }
//     } else if (CanEnter != "True") {
//       document.getElementById("popup_c").style.display = "block";
//     } else if (MrsOpen != "True") {
//       document.getElementById("popup_l").style.display = "block";
//     }
// }
// async function exam_card(n) {
//     if (!navigator.onLine) {
//       window.alert("Check Internet Connection!");
//       router.push({ name: "login" });
//     }
//     document.getElementById("overlay").style.display = "block";
//     document.getElementById("popup_loader").style.display = "flex";
//     var grade = localStorage.getItem("grade");
//     var code = localStorage.getItem("code");
//     var name = localStorage.getItem("name");
//     var quiz_name = `exam${n}`;

//     let request = await fetch(
//       `https://arugatu.000webhostapp.com/index.php?func=MrsOpen&code=${code[0]}${code[1]}${code[2]}&grade=${grade}&quizname=${quiz_name}`
//     );
//     let MrsOpen = await request.text();

//     let request2 = await fetch(
//       `https://arugatu.000webhostapp.com/index.php?func=CanEnter&code=${code}&username=${name}&quiz=${quiz_name}`
//     );
//     let CanEnter = await request2.text();
//     document.getElementById("popup_loader").style.display = "none";
//     if (CanEnter === "True" && MrsOpen === "True") {
//       localStorage.setItem("type", "ex");
//       localStorage.setItem("quiz_name", quiz_name);
//       if (grade === "3") {
//         document.getElementById("overlay").style.display = "none";
//         window.location.href = "../exam3"
//       }
//     } else if (CanEnter != "True") {
//       document.getElementById("popup_c").style.display = "block";
//     } else if (MrsOpen != "True") {
//       document.getElementById("popup_l").style.display = "block";
//     }
// }
// async function toc_card(n) {
//     if (!navigator.onLine) {
//       window.alert("Check Internet Connection!");
//       return false;
//     }
//     document.getElementById("overlay").style.display = "block";
//     document.getElementById("popup_loader").style.display = "flex";
//     var grade = localStorage.getItem("grade");
//     var code = localStorage.getItem("code");
//     var name = localStorage.getItem("name");
//     var quiz_name = `toc${n}`;

//     let request = await fetch(
//       `https://arugatu.000webhostapp.com/index.php?func=MrsOpen&code=${code[0]}${code[1]}${code[2]}&grade=${grade}&quizname=${quiz_name}`
//     );
//     let MrsOpen = await request.text();

//     let request2 = await fetch(
//       `https://arugatu.000webhostapp.com/index.php?func=CanEnter&code=${code}&username=${name}&quiz=${quiz_name}`
//     );
//     let CanEnter = await request2.text();
//     document.getElementById("popup_loader").style.display = "none";
//     document.getElementById("overlay").style.display = "none";
//     if (CanEnter === "True" && MrsOpen === "True") {
//       localStorage.setItem("type", "toc");
//       localStorage.setItem("quiz_name", quiz_name);
//       if (grade === "3") {
//         document.getElementById("overlay").style.display = "none";
//         window.location.href = "/toc"
//       }
//     } else if (CanEnter != "True") {
//       document.getElementById("popup_c").style.display = "block";
//     } else if (MrsOpen != "True") {
//       document.getElementById("popup_l").style.display = "block";
//     }
// }
// async function urt_card(n) {
//     if (!navigator.onLine) {
//       window.alert("Check Internet Connection!");
//       window.location.href = "/"
//     }
//     document.getElementById("overlay").style.display = "block";
//     document.getElementById("popup_loader").style.display = "flex";
//     var grade = localStorage.getItem("grade");
//     var code = localStorage.getItem("code");
//     var name = localStorage.getItem("name");
//     var quiz_name = `urt${n}`;

//     let request = await fetch(
//       `https://arugatu.000webhostapp.com/index.php?func=MrsOpen&code=${code[0]}${code[1]}${code[2]}&grade=${grade}&quizname=${quiz_name}`
//     );
//     let MrsOpen = await request.text();

//     let request2 = await fetch(
//       `https://arugatu.000webhostapp.com/index.php?func=CanEnter&code=${code}&username=${name}&quiz=${quiz_name}`
//     );
//     let CanEnter = await request2.text();
//     document.getElementById("popup_loader").style.display = "none";
//     if (CanEnter === "True" && MrsOpen === "True") {
//       localStorage.setItem("type", "urt");
//       localStorage.setItem("quiz_name", quiz_name);
//       if (grade === "3") {
//         document.getElementById("overlay").style.display = "none";
//         window.location.href = "/urt"
//       }
//     } else if (CanEnter != "True") {
//       document.getElementById("popup_c").style.display = "block";
//     } else if (MrsOpen != "True") {
//       document.getElementById("popup_l").style.display = "block";
//     }
// }
// function close_pop() {
//     document.getElementById("overlay").style.display = "none";
//     document.getElementById("popup_l").style.display = "none";
//     document.getElementById("popup_c").style.display = "none";
// }